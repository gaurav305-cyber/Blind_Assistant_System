# Read in the file
import os
from pathlib import Path
path="e:\\FYP\\Blind_Assistant_System\\OIDv4_ToolKit\\OID\\"
# b=Path(a)
with open('model_data/Dataset_train.txt', 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace("\\", '/')

# Write the file out again
with open('model_data/Dataset_train.txt', 'w') as file:
  file.write(filedata)