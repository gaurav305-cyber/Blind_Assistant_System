
import os
import sys
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
from tkinter import *
import cv2
import requests
import colorsys
import random
import time
import datetime
import numpy as np
import tensorflow as tf
import pyttsx3
import speech_recognition as sr
from threading import Thread
import requests
from bs4 import BeautifulSoup
from yolov3.yolov3 import Create_Yolov3
from yolov3.utils import load_yolo_weights, detect_image, detect_video, image_preprocess, postprocess_boxes, nms, read_class_names
from yolov3.configs import *

from time import sleep

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[0].id)

# curr_label=""
start = time.time()

def speak(audio):
    global flag2
    engine.say(audio) 

    engine.runAndWait()
    flag2=False

def shut_down():
    print("Shutting down. Thankyou For Using Our Sevice. Take Care, Good Bye.")
    p1=Thread(target=speak,args=("Shutting down. Thankyou For Using Our Sevice. Take Care, Good Bye.",))
    p1.start()
    p2 = Thread(target=transition2)
    p2.start()
    time.sleep(7)
    root.destroy()


def transition2():
    global img1
    global flag
    global flag2
    global frames
    global canvas
    local_flag = False
    for k in range(0,5000):
        for frame in frames:
            if flag == False:
                canvas.create_image(0, 0, image=img1, anchor=NW)
                canvas.update()
                flag = True
                return
            else:
                canvas.create_image(0, 0, image=frame, anchor=NW)
                canvas.update()  
                time.sleep(0.1)
# query = takeCommand().lower()
def draw_bbox(image,bboxes, CLASSES=TRAIN_CLASSES, show_label=True, show_confidence = True, Text_colors=(255,255,0), rectangle_colors=''):   
    
    # global curr_label
    global qry
    NUM_CLASS = read_class_names(CLASSES)
    num_classes = len(NUM_CLASS)
    image_h, image_w, _ = image.shape
    hsv_tuples = [(1.0 * x / num_classes, 1., 1.) for x in range(num_classes)]
    #print("hsv_tuples", hsv_tuples)
    colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
    colors = list(map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), colors))

    random.seed(0)
    random.shuffle(colors)
    random.seed(None)
    # y=0
    # n=0
    
    for i, bbox in enumerate(bboxes):
        
        coor = np.array(bbox[:4], dtype=np.int32)
        score = bbox[4]
        class_ind = int(bbox[5])
        bbox_color = rectangle_colors if rectangle_colors != ''else colors[class_ind]
        bbox_thick = int(0.6 * (image_h + image_w) / 1000)
        if bbox_thick < 1: bbox_thick = 1
        #print(image_h, image_w, bbox_thick)
        fontScale = 0.75 * bbox_thick
        (x1, y1), (x2, y2) = (coor[0], coor[1]), (coor[2], coor[3])

        # put object rectangle
        cv2.rectangle(image, (x1, y1), (x2, y2), bbox_color, bbox_thick*2)
        

        # else:
        #     n=n+1
            

        # print(cas)
        if show_label:
            # get text label
            a=""
            # buzzer = Buzzer(17)
            score_str = " {:.2f}".format(score) if show_confidence else "" 
            label = "{}".format(NUM_CLASS[class_ind]) + score_str
            curr_label="{}".format(NUM_CLASS[class_ind])
            print(curr_label.lower())
            
            t=0
           
            if curr_label.lower() in qry:
                b=qry.replace('find','')
                a=b+ " detected"
                print(a)
                speak(a)
                # time.sleep(7)
                # sys.exit()
                # qry=None

        
    #     # flag=True
    #     # print(a)

            elif "lot" in qry:
               
                if curr_label.lower()=="person":  
                    a="person ahead"
                    print(a)
                    speak(a)
                 
                
                elif curr_label.lower()=="chair":
                    a="chair ahead"
                    print(a)
                    speak(a)
                    # break
                
            
            
            else:
                # t=10
                # while t:
                # mins, secs = divmod(t, 60)
                if curr_label.lower() in qry:
                    b=qry.replace('find','')
                    a=b+ " detected"
                    print(a)
                    speak(a)
                    # qry=None

                else:
                    t=int(time.time()-start)
                    if t>50:
                        a="not found"
                        print(a)
                        speak(a)
                    # qry=None
                        # time.sleep(5)
                        # sys.exit()
                #     else:
                #         timer = '{:02d}:{:02d}'.format(mins, secs)
                #         print(timer, end="\r")
                #         time.sleep(1)
                #         t -= 1
                # tu="time up"
                # if tu=="time up":
                #     b=qry.replace('find','')
                #     c="time up"
                #     speak(c)
                    # time.sleep(7)
                    # cv2.destroyAllWindows()
                    # sys.exit
        # time.sleep(7)
        # print(a)
    #     # flag=True
    #     # break
   
            # speak(a)
                # print("y",y)
            # else:
            #     n=n+1
            
            #     print("n",n)
            # print(cas)

            # get text size
            (text_width, text_height), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_COMPLEX_SMALL,
                                                                  fontScale, thickness=bbox_thick)
            # put filled text rectangle
            cv2.rectangle(image, (x1, y1), (x1 + text_width, y1 - text_height - baseline), bbox_color, thickness=cv2.FILLED)

            # put text above rectangle
            cv2.putText(image, label, (x1, y1-4), cv2.FONT_HERSHEY_COMPLEX_SMALL,
                        fontScale, Text_colors, bbox_thick, lineType=cv2.LINE_AA)
            # return cas
            # return y
        
    
    # print(query)
    # canvas2.create_text(10, 225, anchor=NW, text=a, font=('Candara Light', -25,'bold italic'),fill="white", width=350)
    # flag2 = False
    # loading.destroy()

    # p1=Thread(target=speak,args=(a,))
    # p1.start()
    
    return image




def detect_realtime(YoloV3, input_size, show, CLASSES, score_threshold, iou_threshold, rectangle_colors):
    
    # YoloV3=yolo
    # input_size=416
    # show=True
    # CLASSES=TRAIN_CLASSES
    # score_threshold=0.3
    # iou_threshold=0.45
    # rectangle_colors=(255,0,0)
   
    times = []
    vid = cv2.VideoCapture(0)

    # by default VideoCapture returns float instead of int
    # width = int(vid.get(cv2.CAP_PROP_FRAME_WIDTH))
    # height = int(vid.get(cv2.CAP_PROP_FRAME_HEIGHT))
    # fps = int(vid.get(cv2.CAP_PROP_FPS))
    # codec = cv2.VideoWriter_fourcc(*'XVID')
    # out = cv2.VideoWriter(output_path, codec, fps, (width, height)) # output_path must be .mp4

    while True:
        _, frame = vid.read()

        try:
            original_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            original_frame = cv2.cvtColor(original_frame, cv2.COLOR_BGR2RGB)
        except:
            break
        image_frame = image_preprocess(np.copy(original_frame), [input_size, input_size])
        image_frame = tf.expand_dims(image_frame, 0)
        
        t1 = time.time()
        pred_bbox = YoloV3.predict(image_frame)
        t2 = time.time()
        
        pred_bbox = [tf.reshape(x, (-1, tf.shape(x)[-1])) for x in pred_bbox]
        pred_bbox = tf.concat(pred_bbox, axis=0)

        bboxes = postprocess_boxes(pred_bbox, original_frame, input_size, score_threshold)
        bboxes = nms(bboxes, iou_threshold, method='nms')
        
        times.append(t2-t1)
        times = times[-20:]
        print("Time: {:.2f}ms".format(sum(times)/len(times)*1000))
        
        frame = draw_bbox(original_frame, bboxes, CLASSES=CLASSES, rectangle_colors=rectangle_colors)
        frame = cv2.putText(frame, "Time: {:.2f}ms".format(sum(times)/len(times)*1000), (0, 30),cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 0, 255), 2)

        # if output_path != '': out.write(frame)
        

        if show:
            cv2.imshow('output', frame)
            if cv2.waitKey(25) & 0xFF == ord("q"):
                cv2.destroyAllWindows()
                break

    
            
    
    # print(get_label)
    vid.release()
    cv2.destroyAllWindows()
    # canvas2.create_text(10, 225, anchor=NW, text=a, font=('Candara Light', -25,'bold italic'),fill="white", width=350)
    # flag2 = False
    # loading.destroy()

    # p1=Thread(target=speak,args=(a,))
    # p1.start()
    # p2 = Thread(target=transition2)
    # p2.start()
    # flag=False

 # use custom weights
    
# def speak(text):
#     global flag
#     engine.say(text)
#     engine.runAndWait()
#     flag=False
# def get_label():
#   return curr_label
def wishme():
    global canvas2
    hour = datetime.datetime.now().hour

    if 0 <= hour < 12:
        text = "Good Morning sir. I am blind assistant system. How can I Serve you?"
    elif 12 <= hour < 18:
        text = "Good Afternoon sir. I am blind assistant system. How can I Serve you?"
    else:
        text = "Good Evening sir. I am blind assistant system. How can I Serve you?"

    canvas2.create_text(10,10,anchor =NW , text=text,font=('Candara Light', -25,'bold italic'), fill="white",width=350)
    p1=Thread(target=speak,args=(text,))
    p1.start()
    p2 = Thread(target=transition2)
    p2.start()   

    # canvas2.create_text(10,10,anchor =NW , text=text,font=('Candara Light', -25,'bold italic'), fill="white",width=350)
    # p1=Thread(target=speak,args=(text,))
    # p1.start()
    # p2 = Thread(target=transition2)
    # p2.start()

def takecommand():
    global loading
    global flag
    global flag2
    global canvas2
    global qry
    global img4
    if flag2 == False:
        canvas2.delete("all")
        canvas2.create_image(0,0, image=img4, anchor="nw")

    speak("I am listening.")
    flag= True
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        #r.pause_threshold = 3
        audio = r.listen(source)

    try:
        print("Recognizing..")
        # print("Say that again please")
        query = r.recognize_google(audio, language='en-in')
        print(f"user Said :{query}\n")
        qry = query.lower()
        canvas2.create_text(490, 120, anchor=NE, justify = RIGHT ,text=query, font=('fixedsys', -30),fill="white", width=350)
        global img3
        loading = Label(root, image=img3, bd=0)
        loading.place(x=900, y=622)

    except Exception as e:
        print(e)
        print("Say that again please")
        
        speak("Say that again please")
        return None
# def takeCommand():
#     #It takes microphone input from the user and returns string output

#     r = sr.Recognizer()
#     with sr.Microphone() as source:
#         print("Listening...")
#         r.pause_threshold = 1
#         audio = r.listen(source)

#     try:
#         print("Recognizing...")    
#         query = r.recognize_google(audio, language='en-in')
#         print(f"User said: {query}\n")

#     except Exception as e:
#         print(e)    
#         print("Say that again please...")  
#         return "None"
#     return query
def main_window():
    global qry
    wishme()
    while True:
        if qry != None:
            if 'shutdown' in qry or 'quit' in qry or 'stop' in qry or 'goodbye' in qry:
                shut_down()
                break
            else:
                # detection(query)
                # query=None
                if 'person' in qry or 'chair' in qry or 'lot' in qry or 'glasses' in qry or 'mobile' in qry:
                    input_size = YOLO_INPUT_SIZE
                    Darknet_weights = YOLO_DARKNET_WEIGHTS
                    yolo = Create_Yolov3(input_size=input_size, CLASSES=TRAIN_CLASSES)
                    yolo.load_weights("./checkpoints/yolov3_custom")
                    
                    # x=0
                    
                        
                    # if 1:
                        # qry = takeCommand().lower() #Converting user query into lower case

                        # Logic for executing tasks based on query
                    # print(get_label())
                    detect_realtime(yolo,input_size=416, show=True, CLASSES=TRAIN_CLASSES,score_threshold=0.3,iou_threshold=0.45, rectangle_colors=(255,0,0))
                    qry=None
                else:
                    speak("I am afraid I cannot search that")
                    print("I am afraid I cannot search that")
                    qry=None
               
                    
            #        sss         
               
    

    

if __name__ == '__main__':
    
    loading = None
    qry = None
    flag = True
    flag2 = True

    engine = pyttsx3.init() # Windows
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    rate = engine.getProperty('rate')
    engine.setProperty('rate', rate-10)

    root=Tk()
    root.title("Blind Assistant System")
    root.geometry('1360x690+-5+0')
    root.configure(background='white')

    img1= PhotoImage(file='images/chatbot-image.png')
    img2= PhotoImage(file='images/button-green.png')
    img3= PhotoImage(file='images/icon.png')
    img4= PhotoImage(file='images/terminal.png')
    background_image=PhotoImage(file="images/last.png")
    f = Frame(root,width = 1360, height = 690)
    f.place(x=0,y=0)
    f.tkraise()
    front_image = PhotoImage(file="images/front2.png")
    okVar = IntVar()
    btnOK = Button(f, image=front_image,command=lambda: okVar.set(1) )
    btnOK.place(x=0,y=0)
    f.wait_variable(okVar)
    f.destroy()    

    background_label = Label(root, image=background_image)
    background_label.place(x=0, y=0)

    frames = [PhotoImage(file='images/chatgif.gif',format = 'gif -index %i' %(i)) for i in range(20)]
    canvas = Canvas(root, width = 800, height = 596)
    canvas.place(x=10,y=10)
    canvas.create_image(0, 0, image=img1, anchor=NW)
    question_button = Button(root,image=img2, bd=0, command=takecommand)
    question_button.place(x=200,y=625)

    frame=Frame(root,width=500,height=596)
    frame.place(x=825,y=10)
    canvas2=Canvas(frame,bg='#FFFFFF',width=500,height=596,scrollregion=(0,0,500,900))
    vbar=Scrollbar(frame,orient=VERTICAL)
    vbar.pack(side=RIGHT,fill=Y)
    vbar.config(command=canvas2.yview)
    canvas2.config(width=500,height=596, background="black")
    canvas2.config(yscrollcommand=vbar.set)
    canvas2.pack(side=LEFT,expand=True,fill=BOTH)
    canvas2.create_image(0,0, image=img4, anchor="nw")

    task = Thread(target=main_window)
    task.start()
    root.mainloop()

    # input_size = YOLO_INPUT_SIZE
    # Darknet_weights = YOLO_DARKNET_WEIGHTS

    # image_path   = "./IMAGES/street_drive.mp4"
# video_path   = "./IMAGES/street_drive.mp4"

    
# YoloV3, output_path, input_size=416, show=False, CLASSES=YOLO_COCO_CLASSES, score_threshold=0.3, iou_threshold=0.45, rectangle_colors=''
#detect_video(yolo, video_path, "./IMAGES/street_drive_custom.mp4", input_size=input_size, show=True, CLASSES=TRAIN_CLASSES, rectangle_colors=(255,0,0))
#detect_realtime(yolo, '', input_size=input_size, show=True, CLASSES=TRAIN_CLASSES, rectangle_colors=(255, 0, 0))
